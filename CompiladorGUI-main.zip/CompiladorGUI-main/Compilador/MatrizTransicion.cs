﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador
{
    public class MatrizTransicion
    {
        //Columnas:
        // 0 = Letra o '_'
        // 1 = Digito
        // 2 = Espacio en blanco
        // 3 = Otro simbolo (por ejemplo: operadores, delimitadores, etc.)

        // Estados o renglones:
        // 100 = Aceptar ID/palabra reservada
        // 200 = Aceptar numero entero
        // 300 = Error lexico

        private readonly int[,] _matriz =
        {
            //         L     D   ESP  OTRO
            /*0*/ {    1,    2,    0,  501}, //Inicio
            /*1*/ {    1,    1,  100,  100}, //ID o palabra reservada
            /*2*/ {  501,    2,  200,  200}  //Numero entero
        };

        public int ObtenerColumna(char c)
        {
            if(char.IsLetter(c) || c == '_')
                return 0; //Columna de letras/underscore

            if (char.IsDigit(c))
                return 1; //Digito

            if(char.IsWhiteSpace(c)) 
                return 2; //Espacios

            return 3; //Otros caracteres
        }

        public int SiguienteEstado(int estado, int columna)
        {
            //Segun la cantidad de estados
            if (estado < 0 || estado > 2)
                throw new ArgumentOutOfRangeException(nameof(estado));

            return _matriz[estado, columna];
        }
    }
}
