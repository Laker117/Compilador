﻿using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador
{
    internal class AnalizadorLexico
    {
        private readonly MatrizTransicion _matriz;
        private readonly PalabrasReservadas _palabrasReservadas;

        public AnalizadorLexico()
        {
            _matriz = new MatrizTransicion();
            _palabrasReservadas = new PalabrasReservadas();
        }

        public ResultadoLexico Analizar(CodigoFuente fuente)
        {
            var resultado = new ResultadoLexico();
            resultado.AgregarAviso("Lexico iniciado");

            try
            {
                for(int numLinea = 1; numLinea <= fuente.NumeroLineas; numLinea++)
                {
                    ProcesarLinea(fuente.ObtenerLinea(numLinea), numLinea, resultado);
                }

                resultado.AgregarAviso("Lexico finalizado exitosamente");
            }
            catch (Exception ex)
            {
                resultado.AgregarAviso("Error grave en lexico: " + ex.Message);
            }

            return resultado;
        }

        private void ProcesarLinea(string lineaOriginal, int numLinea, ResultadoLexico resultado)
        {
            int estado = 0; ;
            var lexema = new StringBuilder();
            int token = 0;

            //Agregar espacio al final para forzar cierre de lexemas
            string linea = (lineaOriginal ?? string.Empty) + " ";
            for(int i = 0; i < linea.Length; i++)
            {
                char c = linea[i];
                int columna = _matriz.ObtenerColumna(c);
                int valorMatriz = _matriz.SiguienteEstado(estado, columna);
                
                if(valorMatriz == 0)
                {
                    //Reset
                    estado = 0;
                    lexema.Clear();
                    token = 0;
                }
                else if(valorMatriz < 100)
                {
                    //Estado interno (leyendo ID o numero)
                    estado = valorMatriz;
                    lexema.Append(c);
                    token = 0;
                }
                else if(valorMatriz == 100)
                {
                    //Fin de ID/palabra reservada
                    string lex = lexema.ToString();
                    token = _palabrasReservadas.ObtenerToken(lex);
                    resultado.Tokens.Add(new Token(token, lex, numLinea));
                    Console.WriteLine($"Token: {token} | Lexema: {lex} | Linea: {numLinea}");
                    lexema.Clear();
                    estado = 0;
                    i--; //reprocesa el mismo caracter en el estado 0
                }
                else if(valorMatriz == 200)
                {
                    //Fin del numero entero
                    string lex = lexema.ToString();
                    token = 200; //Codigo para numero entero
                    resultado.Tokens.Add(new Token(token, lex, numLinea));
                    Console.WriteLine($"Token: {token} | Lexema: {lex} | Linea: {numLinea}");
                    lexema.Clear();
                    estado = 0;
                    i--; //Procesar el mismo caracter en el estado 0
                }
                else if(valorMatriz  > 500)
                {
                    //Error lexico
                    string mensaje = $"ERROR: En linea [{numLinea}] simbolo no reconocido: '{c}'";
                    resultado.AgregarAviso(mensaje);
                    Console.WriteLine(mensaje);
                    //Reset tras el error
                    estado = 0;
                    lexema.Clear();
                    token = valorMatriz;
                }
            }
        }
    }
}
