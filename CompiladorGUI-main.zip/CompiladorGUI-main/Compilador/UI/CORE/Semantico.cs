using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador.UI.CORE
{
    public class Semantico
    {
        public List<Simbolo> TablaSimbolos { get; private set; }
        public List<string> Errores { get; private set; }

        public Semantico()
        {
            TablaSimbolos = new List<Simbolo>();
            Errores = new List<string>();
        }

        /// <summary>
        /// Registra una variable en la tabla de símbolos.
        /// Valida que no haya sido declarada previamente.
        /// </summary>
        public void RegistrarVariable(string nombre, string tipo, int linea)
        {
            if (TablaSimbolos.Any(s => s.Nombre == nombre))
            {
                Errores.Add($"Error Semántico en línea {linea}: La variable '{nombre}' ya ha sido declarada anteriormente.");
            }
            else
            {
                TablaSimbolos.Add(new Simbolo(nombre, tipo, linea));
            }
        }

        /// <summary>
        /// Valida que una variable exista y que el tipo de dato sea exactamente igual al declarado.
        /// </summary>
        /// <param name="nombre">Nombre de la variable a la que se le asigna un valor.</param>
        /// <param name="tipoValorToken">Token del valor (201 para INT, 202 para FLOAT).</param>
        /// <param name="linea">Línea donde ocurre la asignación.</param>
        public void ValidarAsignacion(string nombre, int tipoValorToken, int linea)
        {
            // 1. Validar que la variable existe (Declaración previa)
            var simbolo = TablaSimbolos.FirstOrDefault(s => s.Nombre == nombre);

            if (simbolo == null)
            {
                Errores.Add($"Error Semántico en línea {linea}: La variable '{nombre}' no ha sido declarada.");
                return;
            }

            // 2. Determinar el tipo del valor que se intenta asignar
            string tipoValor = "";
            if (tipoValorToken == 201) tipoValor = "INT";
            else if (tipoValorToken == 202) tipoValor = "FLOAT";
            else tipoValor = "DESCONOCIDO";

            // 3. Validar coincidencia exacta de tipos (Requerimiento estricto)
            if (simbolo.Tipo != tipoValor)
            {
                Errores.Add($"Error Semántico en línea {linea}: Incompatibilidad de tipos. " +
                           $"No se puede asignar un valor '{tipoValor}' a la variable '{nombre}' que fue declarada como '{simbolo.Tipo}'.");
            }
        }

        /// <summary>
        /// Limpia la tabla y los errores para un nuevo análisis.
        /// </summary>
        public void Reiniciar()
        {
            TablaSimbolos.Clear();
            Errores.Clear();
        }
    }
}
